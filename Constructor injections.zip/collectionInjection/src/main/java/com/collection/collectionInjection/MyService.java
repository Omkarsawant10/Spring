package com.collection.collectionInjection;

import java.util.List;

public class MyService {
	private final List<String> StringList;
	
	public MyService(List<String> StringList)
	{
		this.StringList=StringList;
	}
	
	public void printValues()
	{
		System.out.println(StringList);
	}
	
}
