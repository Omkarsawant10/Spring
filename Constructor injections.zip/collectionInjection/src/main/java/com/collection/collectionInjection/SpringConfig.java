package com.collection.collectionInjection;

import java.util.Arrays;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {

	@Bean
	public MyService myService()
	{
		List<String> list = Arrays.asList("Aditya","Rajesh","Sakhadeo");
		return new MyService(list);
	}
	
}
