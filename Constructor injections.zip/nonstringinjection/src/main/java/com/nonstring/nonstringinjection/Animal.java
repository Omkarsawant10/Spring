package com.nonstring.nonstringinjection;

public class Animal {
private int id;
private String name;
	public int getId(int id)
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	
	public String getName(String name)
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	@Override
    public String toString() {
        return "Person{id=" + id + " ,name="+ name +"}";
    }
}
