package com.nonstring.nonstringinjection;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        try (AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(SpringConfig.class)) {

       // Retrieving the MyService bean from the context
       MyService myService = context.getBean(MyService.class);

       // Calling a method that uses the injected List of Persons
       myService.printAnimal();
   }
    }
}
