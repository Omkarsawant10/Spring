package com.nonstring.nonstringinjection;

import java.util.List;

public class MyService {
private final List<Animal> animalList;

public MyService(List<Animal> animalList)
{
	this.animalList = animalList;
}

public void printAnimal()
{
	System.out.println(animalList);
}
}
