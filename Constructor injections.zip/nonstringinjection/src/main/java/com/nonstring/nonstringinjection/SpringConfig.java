package com.nonstring.nonstringinjection;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {

	@Bean
	public Animal animal1()
	{
		Animal animal = new Animal();
		animal.setId(1);
		animal.setName("Aditya");
		return animal;
	}
	
	@Bean
	public Animal animal2()
	{
		Animal animal = new Animal();
		animal.setId(2);
		animal.setName("ABCD");
		return animal;
	}
	
	@Bean
	public MyService myService(List<Animal> animalList)
	{
		return new MyService(animalList);
	}
	
}
