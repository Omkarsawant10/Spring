package com.first.firstProject;

public class MyService {
	private final MyDependency myDepen;
	
	public MyService(MyDependency myDepen)
	{
		this.myDepen = myDepen;
	}
	
	public void do_something()
	{
		myDepen.do_work();
	}
}
