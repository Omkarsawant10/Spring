package com.first.firstProject;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
public class App 
{
    public static void main( String[] args )
    {
    	 try (AnnotationConfigApplicationContext context =
                 new AnnotationConfigApplicationContext(SpringConfig.class)) {

            MyService myService = context.getBean(MyService.class);
            myService.do_something();
        }
    }
}
