package com.first.firstProject;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {

	@Bean
	public MyService myService(MyDependency myDepen)
	{
		return new MyService(myDepen);
	}
	
	@Bean
	public MyDependency myDepen()
	{
		return new MyDependency();
	}
}
