package com.first.firstProject;

public class MyDependency {
	public void do_work()
	{
		System.out.println("MyDependency is working");
	}
}
