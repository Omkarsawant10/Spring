package com.example.firstSpring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	Employee e;
    public static void main(String args[]) {
        // Specify the path to your XML configuration file
        ApplicationContext ctx = new ClassPathXmlApplicationContext("NewFile.xml");

        Employee emp = (Employee) ctx.getBean("emp1");

        System.out.println(emp);
    }
}
